 #!/bin/bash    

# This is a testing script for RPN assignment for Upsight

echo -e " -- \t Test Script Running \t --"

echo -e " -- \t Compiling files     \t --"

g++ -o test main.cpp linecounter.cpp csvevaluate.cpp

echo -e " -- \t Now running program with 'sample.csv' input \t --"

./test sample.csv

echo -e " --  \t End of Script     \t --"