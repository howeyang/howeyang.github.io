#include <stdio.h>  
#include <stdlib.h>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>


using namespace std;

//Number of rows = Number of Lines that can be grabbed from input csv
int rowcounter(std::string testinput){
	int numlines = 0;
	ifstream inputfile(testinput.c_str()); 

	string aline;
	while (getline(inputfile, aline))
	{
		//increment per line
		if (!aline.empty())
			numlines ++;
	}
	//close stream
	inputfile.close();

	return numlines;
}

//Number of Columns = Commas + 1
int columncounter(std::string testinput){

	ifstream inputfile(testinput.c_str());
	string aline;
	getline(inputfile, aline);

	int count = 0;
	//increment at commas
	for (int i = 0; i < aline.size(); i++){
		if (aline[i] == ',') count++;
	}
	//close stream
	inputfile.close();
	return count + 1 ;
}

//Parse, seperate a line by commans and sort it into the array
void parse(std::string ** testinput, std::string csvinput){

	ifstream aInputFile(csvinput.c_str()); 

	stringstream ss;
	string aLineStr;

	int counterrow = 0;
	int countercol = 0;

	while (getline(aInputFile, aLineStr))
	{	
		ss << aLineStr;
		while( ss.good() )
		{
			//seperate by each comma and parse into array
			string substr;
			getline( ss, substr, ',' );
			testinput[countercol][counterrow] = substr;
			countercol = countercol + 1;
		}
		counterrow = counterrow + 1;
		countercol = 0;
		ss.clear();
	}
	aInputFile.close();
}