#include <string>
// Header Guard to prevent any overlap 
#ifndef LINECOUNTER_H
#define LINECOUNTER_H

//These functions just help initialize the array
int rowcounter(std::string testinput);

int columncounter(std::string testinput);

void parse(std::string ** testinput, std::string csvinput);


#endif