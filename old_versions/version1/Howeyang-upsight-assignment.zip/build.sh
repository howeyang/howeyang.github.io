 #!/bin/bash    

# This is a testing script for RPN assignment for Upsight

echo -e " -- \t Build Script Running                \t --"

echo -e " -- \t Compiling files                     \t --"

echo " g++ -o kontagent_ss  main.cpp linecounter.cpp csvevaluate.cpp"

g++ -o kontagent_ss  main.cpp linecounter.cpp csvevaluate.cpp

echo -e " -- \t How to use kontagent_ss             \t --"

echo -e " -- \t ./kontagent_ss INPUTCSV             \t --"

echo -e " -- \t Result will be output to std output \t --"

echo -e " -- \t Example usage:                      \t --"

echo -e " -- \t ./kontagent_ss sample.csv > target  \t --"

echo -e " --  \t End of Script                      \t --"

