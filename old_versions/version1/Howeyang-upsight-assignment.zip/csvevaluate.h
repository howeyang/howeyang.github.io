#include <string>
// Header Guard to prevent any overlap 
// Modularized the code for evaluating csv input to csvevaluate.cpp
#ifndef CSVEVALUATE_H
#define CSVEVALUATE_H
//Takes in a pointer to the array, and info about the array
void csvevaluate(std::string ** csvarray, int numrow, int numcolumn);

#endif