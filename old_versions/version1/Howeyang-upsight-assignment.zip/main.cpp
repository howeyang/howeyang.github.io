#include <stdio.h>  
#include <stdlib.h>
#include <string>
#include <iostream>
#include <fstream>
#include <stack>

#include "linecounter.h"
#include "csvevaluate.h"

using namespace std;

/* Howe Yang - Prescreen Question for Upsight -- */

// Input : CSV file
// Output : CSV format to std::out with proper RPN evaluations or references

//Helper functions ====================
// Modularized a lot of the code to seperate files
// - Located in linecounter.cpp and .h 
	// --- columncounter(string file)			--> returns number of columns in a csv
	// --- rowcounter(string file)  			--> returns number of forws in a csv
	// --- parse(string[][] array, string file)	--> parses a csv into an array

// - Located in csvevaluate.cpp and .h
	//- --- evaluate(string[][]array, int rows, int coumns) --> does all calcuations for evaluations and referencing for an array



//Main Function    ====================
int main(int argc, char* argv[]) {
	// Unncessary for any checks - like if file input is valid or parameter check -- code omitted

	//Parse input parameter into a string array
	string csvinput = argv[1];

	//Determine number of columns and rows to dynamically allocate an array
	int numcolumn = columncounter(csvinput);
	int numrow = rowcounter(csvinput);
	int counter = 0;

	// Initialize the CSV array holding the values
	// --- Array is my choice of a data structure because of the restraint on 1 million rows -- not that expensive for space
	//     And the alternative of something like a red-black tree, is O(logn) cost of insert and access vs array insert and access O(1)
	string ** csvarray = new string * [numcolumn];

	for(int i = 0; i < numcolumn; i++){
		csvarray[i] = new string[numrow];
		//Fill the array with 0s to resolve any possible blanks
		for(int j = 0; j < numrow; j ++){
			csvarray[i][j] = "0";
		}
	}

	//Now parsing the array with input -- essential
	parse(csvarray, csvinput);

	//for those that require evaluation, there will be a = sign
	// 1. Read the first char of the string in the cell from the CSV
	// if the char is a space -- skip 
	// if the char is = --> handle it as a evaluation
	// if the char != these two cases, its a legit value <-- string to float.

	//The code has been modularized in csvevaluate.cpp -- lots of code

	csvevaluate(csvarray, numrow, numcolumn);


	//Print out csv to output
	for(int i = 0; i < numrow; i++){
		for(int j = 0; j < numcolumn; j ++){
			cout << csvarray[j][i];
			//make sure you dont comma last element in a row
			if(j < numcolumn - 1){
				cout << ",";
			}
		}
		cout << endl;
	}


	// Clean up ----
	//Free CSV Array -- prevent memory leaks, checked via valgrind
	for(int j = 0; j < numcolumn; j ++){
		delete [] csvarray[j];
		csvarray[j] = NULL;
	}
	delete [] csvarray;
	csvarray = NULL;


	return 0;
}	
