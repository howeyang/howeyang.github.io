#include <stdio.h>  
#include <stdlib.h>
#include <string>
#include <iostream>
#include <fstream>
#include <stack>
#include <sstream>

using namespace std;
//Helper function to help deal with what to do if valid entries and how to evaluate calculations and references

void csvevaluate(std::string ** csvarray, int numrow, int numcolumn){
	//for those that require evaluation, there will be a = sign
	// 1. Read the first char of the string in the cell from the CSV
	// if the char is a space -- skip 
	// if the char is = --> handle it as a evaluation
	// if the char != these two cases, its a legit value <-- string to float.


	//variables to help determine calculation
	bool valid = false;
	bool evaluation = false;
	bool calculate = false;
	bool refcell = false;

	int whichcol = 0;
	int whichrow = 0;

	//refences
	stack <int> refstack;
	//calculatons
	//stack <char> opstack; //not neccessary
	//stack is ideal to preserve last in first out idea of RPN
	stack <float> numstack;


	for(int i = 0; i < numrow; i++){
		for(int j = 0; j < numcolumn; j ++){

			//Iterate through whole string
			//Now handle the three cases
			//If the first char is a '=' this is a evaluation
				//if evaluation determine if its a RPN operation or reference
			//If the first char is not '=', this should be a valid integer
			// Parse it from a string into a float.
			for(int stringcount = 0; stringcount < csvarray[j][i].length(); stringcount ++){ 
				
				//Need to figure what type of work to do
				if(!valid && !evaluation){

				// Case 1 : Spaces located in CSV trim space -- work past the space
					if(csvarray[j][i].at(stringcount) == ' '){
					//Do nothing and iterate to next char
					}else if(csvarray[j][i].at(stringcount) == '='){
						evaluation = true;

						stringcount = stringcount + 1;
					}else if (!evaluation){
						valid = true;
					}
				}
				//End of Case 1 -- 
				//Case 2 : if the input is valid input, not a type of evalution
				// Parse the string into float
				if(valid){

				//parsing string to const char --> then parse to float.
				//This will auto resolve whitespaces, so can just parse whole string without trimming
					const char * tempchar2 = csvarray[j][i].c_str();
					float tempfloat2 = strtof(tempchar2, NULL);
					ostringstream buffer2;
					buffer2 << tempfloat2;
					csvarray[j][i] = buffer2.str();

				//Break out of loop -- job done
					break;
				}
				//End of Case 2 --

				//Case 3: if there is =, need to evaluate
				//Two subcases:
				// 1) referncing another cell in array 
				// 2) doing an RPN calcuation

				//Just in case, ignore whitespace
				if(csvarray[j][i].at(stringcount) == ' '){
					//Do nothing and iterate to next char
				}else if(evaluation){
					//First find first non space character in string past =
					int testASCII = csvarray[j][i].at(stringcount) - 'A';

					//Case if Reference
					if(testASCII >= 0){
						refcell = true;
						whichcol = testASCII;
						stringcount = stringcount + 1;
						whichrow = atoi(csvarray[j][i].substr(stringcount, csvarray[j][i].length()).c_str()) - 1;

						// I want to reference an address but c++ kept complaining  :: eg. csvarray[i][j] = &csvarray[whichcol][whichrow];

						//Push information to the stack
						refstack.push(i);
						refstack.push(j);
						refstack.push(whichrow);
						refstack.push(whichcol);
						break;

					//Case if Calcuation
					}else{
						calculate = true;
						//Need to make use of 2 stacks:
						// opstack = holds operators (not necessary) numstack = hold operands

						//Just need to seperate each number by whitespace
						//trying to stringstream
						stringstream ss;
						string stringline;

						//for calculating
						float rightside = 0;
						float leftside = 0;

						ss << csvarray[j][i].substr(stringcount, csvarray[j][i].length()).c_str();

						while(ss.good()){
							string substr;
							getline( ss, substr, ' ' );

							//if operand -- wanted to use switch case but doesnt support strings
							if(substr == "+"|| substr == "-"|| substr == "*"|| substr == "/" ){

								//Addition
								if(substr == "+"){
									rightside = numstack.top();
									numstack.pop();
									leftside = numstack.top();
									numstack.pop();
									numstack.push(leftside + rightside);
								}
								//Substraction
								if(substr == "-"){
									rightside = numstack.top();
									numstack.pop();
									leftside = numstack.top();
									numstack.pop();
									numstack.push(leftside - rightside);
								}

								//Multiplication
								if(substr == "*"){
									rightside = numstack.top();
									numstack.pop();
									leftside = numstack.top();
									numstack.pop();
									numstack.push(leftside * rightside);
								}

								//Division
								if(substr == "/"){
									rightside = numstack.top();
									numstack.pop();
									leftside = numstack.top();
									numstack.pop();
									numstack.push(leftside / rightside);
								}

							//if number -- push it to the stack
							}else{
								//convert string to float
								const char * tempchar = substr.c_str();
								float tempfloat = strtof(tempchar, NULL);
								numstack.push(tempfloat);
							}
						}

						//push float to string -- kinda bad, but dont wanna allocate space for float array
						ostringstream buffer;
						buffer << numstack.top();
						csvarray[j][i] = buffer.str();
						numstack.pop();
						buffer.clear();
						ss.clear();
						break;
					}
				}
			}


		//Finished parsing a cell in CSV
		//reset flags on what type of work to do
			valid = false;
			evaluation = false;
			calculate = false;
			refcell = false;
			whichrow = 0;
			whichcol = 0;
		}
		
	}

	//Now dealing with references pushed onto refernence stack
	// Until stack is empty, pop all 4 elements
	// 1-> targetcol 2-> target row 3-> source col 4-> source row

	int targetcol = 0;
	int targetrow = 0;

	while(!refstack.empty()){
		targetcol = refstack.top();
		refstack.pop();
		targetrow = refstack.top();
		refstack.pop();
		whichcol = refstack.top();
		refstack.pop();
		whichrow = refstack.top();
		refstack.pop();
		csvarray[whichcol][whichrow] = csvarray[targetcol][targetrow];
	}



}